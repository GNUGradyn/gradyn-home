'use strict';

var state = require('@dnd-kit/state');
var abstract = require('@dnd-kit/abstract');
var modifiers = require('@dnd-kit/abstract/modifiers');
var geometry = require('@dnd-kit/geometry');
var utilities = require('@dnd-kit/dom/utilities');

// src/modifiers/RestrictToWindow.ts
var RestrictToWindow = class extends abstract.Modifier {
  constructor(manager) {
    super(manager);
    this.previousConstrainedTransform = { x: 0, y: 0 };
    const { dragOperation } = manager;
    const getWindowBoundingRectangle = () => state.untracked(() => {
      var _a;
      const { source } = dragOperation;
      this.windowBoundingRectangle = utilities.getViewportBoundingRectangle(
        (_a = source == null ? void 0 : source.element) != null ? _a : document.documentElement
      );
    });
    this.destroy = state.effect(() => {
      if (dragOperation.status.idle) {
        this.previousConstrainedTransform = { x: 0, y: 0 };
        return;
      }
      this.previousConstrainedTransform = { x: 0, y: 0 };
      getWindowBoundingRectangle();
      window.addEventListener("resize", getWindowBoundingRectangle);
      return () => {
        window.removeEventListener("resize", getWindowBoundingRectangle);
      };
    });
  }
  apply({ shape, transform }) {
    if (!this.windowBoundingRectangle || !shape) {
      return transform;
    }
    const { current } = shape;
    const { left, top, width, height } = current.boundingRectangle;
    const baseLeft = left - this.previousConstrainedTransform.x;
    const baseTop = top - this.previousConstrainedTransform.y;
    const restrictedTransform = modifiers.restrictShapeToBoundingRectangle(
      new geometry.Rectangle(baseLeft, baseTop, width, height),
      transform,
      this.windowBoundingRectangle
    );
    this.previousConstrainedTransform = restrictedTransform;
    return restrictedTransform;
  }
};
var _RestrictToElement = class _RestrictToElement extends abstract.Modifier {
  constructor(manager, options) {
    super(manager, options);
    this.boundingRectangle = state.signal(null);
    this.previousConstrainedTransform = { x: 0, y: 0 };
    this.destroy = state.effect(() => {
      if (!this.options) {
        return;
      }
      const { dragOperation } = manager;
      const { status } = dragOperation;
      if (status.initialized) {
        this.previousConstrainedTransform = { x: 0, y: 0 };
        const { element } = this.options;
        const target = typeof element === "function" ? element(dragOperation) : element;
        if (!target) {
          return;
        }
        let timeout;
        const updateBoundingRectangle = () => {
          this.boundingRectangle.value = utilities.getBoundingRectangle(target);
        };
        const handleScroll = () => {
          if (timeout) {
            return;
          }
          timeout = setTimeout(() => {
            updateBoundingRectangle();
            timeout = void 0;
          }, 25);
        };
        const resizeObserver = new ResizeObserver(updateBoundingRectangle);
        resizeObserver.observe(target);
        document.addEventListener("scroll", handleScroll, {
          passive: true,
          capture: true
        });
        return () => {
          document.removeEventListener("scroll", handleScroll, {
            capture: true
          });
          resizeObserver.disconnect();
          this.boundingRectangle.value = null;
        };
      }
    });
  }
  apply(operation) {
    const { shape, transform } = operation;
    if (!shape) {
      return transform;
    }
    const boundingRectangle = this.boundingRectangle.value;
    if (!boundingRectangle) {
      return transform;
    }
    const { current } = shape;
    const { left, top, width, height } = current.boundingRectangle;
    const baseLeft = left - this.previousConstrainedTransform.x;
    const baseTop = top - this.previousConstrainedTransform.y;
    const restrictedTransform = modifiers.restrictShapeToBoundingRectangle(
      new geometry.Rectangle(baseLeft, baseTop, width, height),
      transform,
      boundingRectangle
    );
    this.previousConstrainedTransform = restrictedTransform;
    return restrictedTransform;
  }
};
_RestrictToElement.configure = abstract.configurator(_RestrictToElement);
var RestrictToElement = _RestrictToElement;

exports.RestrictToElement = RestrictToElement;
exports.RestrictToWindow = RestrictToWindow;
//# sourceMappingURL=modifiers.cjs.map
//# sourceMappingURL=modifiers.cjs.map