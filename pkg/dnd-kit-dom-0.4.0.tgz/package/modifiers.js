import { signal, effect, untracked } from '@dnd-kit/state';
import { configurator, Modifier } from '@dnd-kit/abstract';
import { restrictShapeToBoundingRectangle } from '@dnd-kit/abstract/modifiers';
import { Rectangle } from '@dnd-kit/geometry';
import { getBoundingRectangle, getViewportBoundingRectangle } from '@dnd-kit/dom/utilities';

// src/modifiers/RestrictToWindow.ts
var RestrictToWindow = class extends Modifier {
  constructor(manager) {
    super(manager);
    this.previousConstrainedTransform = { x: 0, y: 0 };
    const { dragOperation } = manager;
    const getWindowBoundingRectangle = () => untracked(() => {
      var _a;
      const { source } = dragOperation;
      this.windowBoundingRectangle = getViewportBoundingRectangle(
        (_a = source == null ? void 0 : source.element) != null ? _a : document.documentElement
      );
    });
    this.destroy = effect(() => {
      if (dragOperation.status.idle) {
        this.previousConstrainedTransform = { x: 0, y: 0 };
        return;
      }
      this.previousConstrainedTransform = { x: 0, y: 0 };
      getWindowBoundingRectangle();
      window.addEventListener("resize", getWindowBoundingRectangle);
      return () => {
        window.removeEventListener("resize", getWindowBoundingRectangle);
      };
    });
  }
  apply({ shape, transform }) {
    if (!this.windowBoundingRectangle || !shape) {
      return transform;
    }
    const { current } = shape;
    const { left, top, width, height } = current.boundingRectangle;
    const baseLeft = left - this.previousConstrainedTransform.x;
    const baseTop = top - this.previousConstrainedTransform.y;
    const restrictedTransform = restrictShapeToBoundingRectangle(
      new Rectangle(baseLeft, baseTop, width, height),
      transform,
      this.windowBoundingRectangle
    );
    this.previousConstrainedTransform = restrictedTransform;
    return restrictedTransform;
  }
};
var _RestrictToElement = class _RestrictToElement extends Modifier {
  constructor(manager, options) {
    super(manager, options);
    this.boundingRectangle = signal(null);
    this.previousConstrainedTransform = { x: 0, y: 0 };
    this.destroy = effect(() => {
      if (!this.options) {
        return;
      }
      const { dragOperation } = manager;
      const { status } = dragOperation;
      if (status.initialized) {
        this.previousConstrainedTransform = { x: 0, y: 0 };
        const { element } = this.options;
        const target = typeof element === "function" ? element(dragOperation) : element;
        if (!target) {
          return;
        }
        let timeout;
        const updateBoundingRectangle = () => {
          this.boundingRectangle.value = getBoundingRectangle(target);
        };
        const handleScroll = () => {
          if (timeout) {
            return;
          }
          timeout = setTimeout(() => {
            updateBoundingRectangle();
            timeout = void 0;
          }, 25);
        };
        const resizeObserver = new ResizeObserver(updateBoundingRectangle);
        resizeObserver.observe(target);
        document.addEventListener("scroll", handleScroll, {
          passive: true,
          capture: true
        });
        return () => {
          document.removeEventListener("scroll", handleScroll, {
            capture: true
          });
          resizeObserver.disconnect();
          this.boundingRectangle.value = null;
        };
      }
    });
  }
  apply(operation) {
    const { shape, transform } = operation;
    if (!shape) {
      return transform;
    }
    const boundingRectangle = this.boundingRectangle.value;
    if (!boundingRectangle) {
      return transform;
    }
    const { current } = shape;
    const { left, top, width, height } = current.boundingRectangle;
    const baseLeft = left - this.previousConstrainedTransform.x;
    const baseTop = top - this.previousConstrainedTransform.y;
    const restrictedTransform = restrictShapeToBoundingRectangle(
      new Rectangle(baseLeft, baseTop, width, height),
      transform,
      boundingRectangle
    );
    this.previousConstrainedTransform = restrictedTransform;
    return restrictedTransform;
  }
};
_RestrictToElement.configure = configurator(_RestrictToElement);
var RestrictToElement = _RestrictToElement;

export { RestrictToElement, RestrictToWindow };
//# sourceMappingURL=modifiers.js.map
//# sourceMappingURL=modifiers.js.map